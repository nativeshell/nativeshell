//
//  NativeShellPods.h
//  NativeShellPods
//
//  Created by Matej Knopp on 7/1/21.
//

#import <Foundation/Foundation.h>

//! Project version number for NativeShellPods.
FOUNDATION_EXPORT double NativeShellPodsVersionNumber;

//! Project version string for NativeShellPods.
FOUNDATION_EXPORT const unsigned char NativeShellPodsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NativeShellPods/PublicHeader.h>


